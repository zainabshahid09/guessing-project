import pygame
import sys

# Initialize Pygame and Mixer
pygame.init()
pygame.mixer.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Celebrity Guessing Game")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GRAY = (100, 100, 100)

# Fonts
font = pygame.font.Font(None, 36)

# Load celebrity images 
celebrity_images = [
      'images/cr.webp',
    'images/taylor.webp',
    'images/zayn.jfif',
    'images/kendal.webp',
    'images/jenna.jfif',
    'images/danial.webp',
    'images/bill.jfif',
    'images/leonardo.jfif',
    'images/elon.jpg',
    'images/obama.jpg',
    'images/goat.jfif'  # 11th level image
]

# Celebrities' names and options for each level
celebrity_data = [
    {'name': 'Ronaldo', 'options': ['Messi', 'Neymar', 'Ronaldo', 'Mbappe']},
    {'name': 'Taylor', 'options': ['Taylor', 'Selena', 'Ariana', 'Beyonce']},
    {'name': 'Zayn Malik', 'options': ['Harry', 'Louis Tomlinson', 'Niall Horan', 'Zayn Malik']},
    {'name': 'Kendal', 'options': ['Kendal', 'Kylie', 'Gigi', 'Kris']},
    {'name': 'Jenna', 'options': ['Bella', 'Emma', 'Jenna', 'Lisa']},
    {'name': 'Danial', 'options': ['Harry', 'Tom Cruise', 'Danial', 'Messi']},
    {'name': 'Bill Gates', 'options': ['Bill Gates', 'Jeff Bezos', 'Elon Musk', 'Mark Zuckerberg']},
    {'name': 'Leonardo DiCaprio', 'options': ['Brad Pitt', 'Leonardo DiCaprio', 'Tom Hanks', 'Johnny Depp']},
    {'name': 'Elon Musk', 'options': ['Jeff Bezos', 'Elon Musk', 'Bill Gates', 'Mark Zuckerberg']},
    {'name': 'Barack Obama', 'options': ['Joe Biden', 'Barack Obama', 'George W. Bush', 'Bill Clinton']},
    {'name': 'Cristiano Ronaldo', 'options': ['Pelé', 'Diego Maradona', 'Lionel Messi', 'Cristiano Ronaldo']}  # 11th level
]

# Game state variables
current_level = 0
score = 0
game_over = False
game_won = False
feedback_color = None
correct_option = None
timer_started = False  # New flag for timing

# Load sound effects
correct_sound = pygame.mixer.Sound('sounds/wrong-answer-129254.mp3')  # Default correct sound
wrong_sound = pygame.mixer.Sound('sounds/buzzer-or-wrong-answer-20582.mp3')  # Default wrong sound

# Load special sounds for the 11th level
special_correct_sound = pygame.mixer.Sound('sounds/Cristiano-Ronaldo-Siuuu-Sound-Effect.mp3')  # Special correct sound for level 11
special_wrong_sound = pygame.mixer.Sound('sounds/buzzer-or-wrong-answer-20582.mp3')  # Special wrong sound for level 11

# Button function
def draw_button(text, x, y, width, height, color, text_color, action=None):
    pygame.draw.rect(screen, color, (x, y, width, height))
    text_surface = font.render(text, True, text_color)
    screen.blit(text_surface, (x + (width - text_surface.get_width()) / 2, y + (height - text_surface.get_height()) / 2))

    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()

    if x + width > mouse[0] > x and y + height > mouse[1] > y:
        if click[0] == 1 and action:
            print("Button clicked!")  # Debug print
            action()

# Start Game button click action
def start_game():
    global current_level, score, game_over, game_won, feedback_color, correct_option, timer_started
    current_level = 0
    score = 0
    game_over = False
    game_won = False
    feedback_color = None
    correct_option = None
    timer_started = False

    game_loop()  # Start the game loop

# Render a level (show celebrity image and options)
def render_level(level):
    screen.fill(WHITE)
    
    # Draw the celebrity image
    celeb_image = pygame.image.load(celebrity_images[level])
    celeb_image = pygame.transform.scale(celeb_image, (300, 300))
    screen.blit(celeb_image, (250, 50))
    
    # Draw the options
    options = celebrity_data[level]['options']
    
    option_buttons = []
    for i, option in enumerate(options):
        color = GRAY  # Default color
        # Check feedback color
        if feedback_color:
            if option == correct_option:
                color = GREEN  # Correct option
            elif option == feedback_color:
                color = RED  # Selected wrong option
        option_buttons.append((option, 100, 400 + (i * 50), 600, 40, color, WHITE))
    
    return option_buttons

# Check answer
def check_answer(selected_option):
    global current_level, score, game_over, game_won, feedback_color, correct_option, timer_started
    
    correct_option = celebrity_data[current_level]['name']  # Get the correct answer
    feedback_color = selected_option  # Store the selected option for feedback

    if selected_option == correct_option:
        score += 1
        # Check if it's the 11th (special) level
        if current_level == 10:
            special_correct_sound.play()  # Play special correct sound for level 11
        else:
            correct_sound.play()  # Play regular correct answer sound
        if current_level == len(celebrity_data) - 1:
            game_won = True
        else:
            current_level += 1  # Move to the next level
    else:
        game_over = True
        # Check if it's the 11th (special) level
        if current_level == 10:
            special_wrong_sound.play()  # Play special wrong sound for level 11
        else:
            wrong_sound.play()  # Play regular wrong answer sound
        timer_started = True  # Start the timer for game over
        pygame.time.set_timer(pygame.USEREVENT, 2000)  # Set a timer for 2 seconds

# Main game loop
def game_loop():
    global current_level, score, game_over, game_won, feedback_color, correct_option, timer_started
    running = True

    while running:
        option_buttons = render_level(current_level)  # Render the options each frame
        
        # Display the score
        score_text = font.render(f"Score: {score}", True, BLACK)
        screen.blit(score_text, (10, 10))
        
        if game_over:
            game_over_text = font.render("Game Over!", True, RED)
            screen.blit(game_over_text, (SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 - 50))
            draw_button("Replay", 350, 400, 100, 50, BLUE, WHITE, start_game)  # Show replay button
        elif game_won:
            win_text = font.render("Congratulations! You won!", True, GREEN)
            screen.blit(win_text, (SCREEN_WIDTH // 2 - 200, SCREEN_HEIGHT // 2 - 50))
        else:
            # Render celebrity image and options
            celeb_image = pygame.image.load(celebrity_images[current_level])
            celeb_image = pygame.transform.scale(celeb_image, (300, 300))
            screen.blit(celeb_image, (250, 50))

            for option in option_buttons:
                draw_button(*option)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not game_over and not game_won:
                mouse_pos = event.pos
                for option in option_buttons:
                    button_rect = pygame.Rect(option[1], option[2], option[3], option[4])
                    if button_rect.collidepoint(mouse_pos):
                        check_answer(option[0])  # Check against correct name
                        option_buttons = render_level(current_level)  # Re-render options after selecting

            if event.type == pygame.USEREVENT:  # Timer event for game over
                if timer_started:
                    pygame.time.set_timer(pygame.USEREVENT, 0)  # Stop the timer
                    feedback_color = None  # Reset feedback color
                    current_level = 0  # Reset the level for replay
                    score = 0  # Reset score
                    game_over = False  # Reset game over status
                    game_loop()  # Restart game loop

        pygame.display.flip()
    pygame.quit()
    sys.exit()

def main_menu():
    # Main menu to start the game
    while True:
        screen.fill(WHITE)
        title_text = font.render("Welcome to Celebrity Guessing Game", True, BLACK)
        screen.blit(title_text, (SCREEN_WIDTH // 2 - title_text.get_width() // 2, 100))
        draw_button("Play", 350, 300, 100, 50, BLUE, WHITE, start_game)  # Ensure action is set

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        
        pygame.display.flip()

# Start the main menu
main_menu()
